The Flex code can be built in the Flex Builder by adding the Flex project to your Eclipse or Flex Builder workspace. Otherwise, you can use the Ant script in the Appendix of the book to build the Flex project.

You can download the latest version of the PureMVC port from:  http://www.puremvc.org

You can download the latest version of Cairngorm from:  http://opensource.adobe.com/wiki/display/cairngorm/Downloads